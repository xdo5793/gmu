//********************************************************* 

/*
 * In this file, do the following things:
 * 1) Modify the class so that it inherits from Product 
 * 2) Create a constructor that takes in a book title and book cost
 */
 

public class Book extends Product {

   public Book (String title, double cost) {
      super(title, cost);
   }

}
